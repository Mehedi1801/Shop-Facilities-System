            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                
                <ul class="nav side-menu">
                  <li><a href="index.php" ><i class="fa fa-home"></i> Home </a>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Member List <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="_candidate.php">Candidate List</a></li>
                      
                      
                     
                    </ul>
                  </li>

                  <li><a href="_member.php"><i class="fa fa-user"></i> Shop Owner </a>
                </li>


                  <li><a><i class="fa fa-desktop"></i> Post <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="_recent.php">Recent post</a></li>
                      <li><a href="_previous.php">Previous post</a></li>
                    </ul>
                  </li>
                  
                 
                    
              </div>
              <div class="menu_section">
      
              </div>

            </div>