 <div class="profile clearfix">
            <div class="profile_pic">
              <img src="../images/picture.jpg" alt="..." class="img-circle profile_img">
            </div>
            <div class="profile_info">
              <span>Welcome,</span>
              <h2><?php echo $_SESSION['admin_name']; ?></h2>
            </div>
          </div>