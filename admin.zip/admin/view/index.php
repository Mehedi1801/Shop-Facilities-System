<?php 

  header("Location: _recent.php");

 ?>