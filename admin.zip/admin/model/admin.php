<?php 

include ('connection.php');

class Admin {

	
	public function register_admin($admin_name, $email, $password_1, $gender, $phone, $address){

		$GLOBALS['sql'] = "INSERT INTO admin_details (admin_name, email , password , gender , phone , address ) VALUES('$admin_name','$email' ,'$password_1' , '$gender' ,'$phone','$address');";

		return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
	}


	public function login_admin($email,$password){
		$GLOBALS['sql'] ="SELECT * FROM admin WHERE email ='$email' and password = '$password'";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function create_report( $email,$catagory,$comment){
		$GLOBALS['sql'] ="INSERT INTO  report_or_notice ( email , catagory , comment ) VALUES('$email' ,'$catagory' , '$comment');";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function check_email($email){
		$GLOBALS['sql'] ="SELECT * FROM admin_details WHERE email ='$email'";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function register_candidate( $name, $phone, $email, $address){
		$GLOBALS['sql'] ="INSERT INTO  candidate (name ,  address, phone, email ) VALUES('$name' , '$address' ,'$phone', '$email');";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

		public function get_candidate_list(){   // 1
			$GLOBALS['sql'] ="SELECT  *  FROM candidate";
			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}  


		public function assign_employee($candidateId, $postId ){   // 1
			$GLOBALS['sql'] ="INSERT INTO  assign (assign_date , candidate_id_candidate , post_id_post ) VALUES(CURDATE() ,'$candidateId' , '$postId');";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		} 



		public function get_candidate_details($id ){   // 1
			$GLOBALS['sql'] ="SELECT * FROM `candidate` where id_candidate = '$id'";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		} 



		public function update_candidate( $candidate_id, $name, $address, $phone){  // 1

			$GLOBALS['sql'] ="UPDATE candidate SET name  = '$name', address = '$address', phone_number  = '$phone'  WHERE id_candidate ='$candidate_id'";

			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
			
			
		}

// Recent 
		public function get_recent_candidate_request_list(){
			$GLOBALS['sql'] ="SELECT * FROM `post` WHERE  id_post not in (SELECT post_id_post from  assign where status = 1)";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function get_recent_meal_request_list(){
			$GLOBALS['sql'] ="SELECT * FROM `meal_booking` where status = 'pending'";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}

		

// Previous

		public function get_previous_candidate_request_list(){
			$GLOBALS['sql'] ="SELECT * FROM `post` WHERE  id_post in (SELECT post_id_post from  assign where status = 1)";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function get_previous_meal_request_list(){
			$GLOBALS['sql'] ="SELECT * FROM `meal_booking` where status = 'accept'";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}

		


		public function get_user_candidate_post_details($id){
			$GLOBALS['sql'] ="SELECT * FROM `post` where id_post = '$id'";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function get_employee_member_list_for_assign($post_id){
			$GLOBALS['sql'] ="SELECT * FROM `candidate` where id_candidate not In (SELECT candidate_id_candidate from  assign where post_id_post = '$post_id')";
			return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
		}


		public function add_notification($status, $type, $post_id, $user_id){
			$GLOBALS['sql'] = "insert into `notification` (status, type, post_id, user_id) VALUES ('$status','$type','$post_id','$user_id');";
			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}



		public function change_meal_booking_status($post_id, $status){
			$GLOBALS['sql'] = "Update `meal_booking` set status = '$status' where booking_id = $post_id;";
			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}


		
		

		public function get_post_by_id($id){    
			$GLOBALS['sql'] ="SELECT  *  FROM post  where   id = ". $id ;
			return mysqli_query( $GLOBALS["conn"], $GLOBALS["sql"]);
		}


	}

	?>