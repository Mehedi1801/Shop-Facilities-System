
<?php

include ('connection.php');
include ('../model/admin.php');



$errors = array();
if (isset($_POST['reg_candidate'])) {

	
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$phone = mysqli_real_escape_string($conn, $_POST['phone']);
	$address = mysqli_real_escape_string($conn, $_POST['address']);




	if (empty($name)) {
		array_push($errors, "Name is required");
	}
	
	if (empty($phone)) { 
		array_push($errors, "Mobile number is required");
	}
	if (empty($email)) { 
		array_push($errors, "Email  is required");
	}
	if (empty($address)) { 
		array_push($errors, "Address  is required");
	}




// Call 
	$objUser = new Admin();       
	if (count($errors) == 0) {

		$result = $objUser->register_candidate( $name, $phone, $email, $address,);  
		array_push($errors, "Successfully Registation");
		// array_push($errors, $result);

		echo $result;
	

	}  
	else {
		array_push($errors, "Registration fail");
	}

} else {
	array_push($errors, " ");
}



?>
