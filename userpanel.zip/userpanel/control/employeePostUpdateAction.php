
<?php

include('connection.php');
include('../model/user.php');

$errors = array();
if (isset($_POST['post_update'])) {

	$position = mysqli_real_escape_string($conn, $_POST['position']);

	$education = mysqli_real_escape_string($conn, $_POST['education']);

	$experience = mysqli_real_escape_string($conn, $_POST['experience']);

	$age = mysqli_real_escape_string($conn, $_POST['age']);

	$working_type = mysqli_real_escape_string($conn, $_POST['working_type']);

	$working_duration = mysqli_real_escape_string($conn, $_POST['working_duration']);

	$month_or_day_number = mysqli_real_escape_string($conn, $_POST['month_or_day_number']);

	$joining_date = mysqli_real_escape_string($conn, $_POST['joining_date']);

	$start_time = mysqli_real_escape_string($conn, $_POST['start_time']);

	$end_time = mysqli_real_escape_string($conn, $_POST['end_time']);

	$salary = mysqli_real_escape_string($conn, $_POST['salary']);

	$working_details = mysqli_real_escape_string($conn, $_POST['working_details']);

	$id_post = mysqli_real_escape_string($conn, $_POST['id']);




	if (empty($joining_date)) {
		array_push($errors, "Joining Date is required");
	}

	if (empty($start_time)) {
		array_push($errors, "Start_time is required");
	}

	if (empty($end_time)) {
		array_push($errors, "End time is required");
	}

	if (empty($id_post)) {
		array_push($errors, "Dont Cheat");
	}


	// Call 
	$objUser = new User();

	if (count($errors) == 0) {

		$result = $objUser->post_for_employee_update(
			$position,
			$education,
			$experience,
			$age,
			$working_type,
			$working_duration,
			$month_or_day_number,
			$joining_date,
			$start_time,
			$end_time,
			$salary,
			$working_details,
			$id_post
		);
		array_push($errors, "Update Successfully ". $result);
		// header("location: ../view/recentPostDetails.php?id=" . $id_post);
	} else {
		array_push($errors, "Update Fails " . $result);
	}
}



?>
