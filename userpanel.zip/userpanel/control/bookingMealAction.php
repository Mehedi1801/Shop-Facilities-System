
<?php

	include ('connection.php');
	include ('../model/user.php');

	

	  $errors = array();
    	if (isset($_POST['post_meal'])) {

		$meal_type = mysqli_real_escape_string($conn, $_POST['meal_type']);
		$person = mysqli_real_escape_string($conn, $_POST['person']);
		$breakfast_time_slot = mysqli_real_escape_string($conn, $_POST['breakfast_time_slot']);
		$launch_time_slot = mysqli_real_escape_string($conn, $_POST['launch_time_slot']);
		$meal_other_requirements = mysqli_real_escape_string($conn, $_POST['meal_other_requirements']);


		if (empty($meal_type)) { 
				array_push($errors, "meal type is required");
			}
		if (empty($person)) {
				array_push($errors, "person is required");
			}
		if (empty($breakfast_time_slot)) { 
				array_push($errors, "breakfast time slot is required");
		}

		if (empty($launch_time_slot)) { 
		 		array_push($errors, "launch time slot Day is required");
     	 }

		$id = $_SESSION['user_id'];


// Call 
	  	$objUser = new User();
          
		if (count($errors) == 0) {
			    
          
	   $result = $objUser->create_meal_booking_request($meal_type, $person, $breakfast_time_slot, $launch_time_slot, $meal_other_requirements, $id);  
             array_push($errors, "Meal service requist is successfull");
            
			}  

        }



?>
