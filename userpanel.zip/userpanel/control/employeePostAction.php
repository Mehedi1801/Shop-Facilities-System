
<?php

include('connection.php');
include('../model/user.php');



$errors = array();
if (isset($_POST['post_servant'])) {

	$position = mysqli_real_escape_string($conn, $_POST['position']);

	$education = mysqli_real_escape_string($conn, $_POST['education']);

	$experience = mysqli_real_escape_string($conn, $_POST['experience']);

	$age = mysqli_real_escape_string($conn, $_POST['age']);

	$working_type = mysqli_real_escape_string($conn, $_POST['working_type']);

	$working_duration = mysqli_real_escape_string($conn, $_POST['working_duration']);

	$month_or_day_number = mysqli_real_escape_string($conn, $_POST['month_or_day_number']);

	$joining_date = mysqli_real_escape_string($conn, $_POST['joining_date']);

	$start_time = mysqli_real_escape_string($conn, $_POST['start_time']);

	$end_time = mysqli_real_escape_string($conn, $_POST['end_time']);

	$salary = mysqli_real_escape_string($conn, $_POST['salary']);

	$working_details = mysqli_real_escape_string($conn, $_POST['working_details']);

	if (empty($joining_date)) {
		array_push($errors, "Joining Date is required");
	}

	if (empty($start_time)) {
		array_push($errors, "Start time is required");
	}

	if (empty($end_time)) {
		array_push($errors, "End time is required");
	}




	// Call 
	$objUser = new User();

	if (count($errors) == 0) {
		$u_id = $_SESSION['user_id'];


		$result = $objUser->post_for_employee(
			$position,
			$education,
			$experience,
			$age,
			$working_type,
			$working_duration,
			$month_or_day_number,
			$joining_date,
			$start_time,
			$end_time,
			$salary,
			$working_details,
			$u_id
		);

		if ($result == 1) {
			array_push($errors, "Servent Post Submit Successfully");
		} else {
			array_push($errors, "Something is wrong , Try again");
		}
	}
}



?>
