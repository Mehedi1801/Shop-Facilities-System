<?php
include 'header.php';
if (isset($_SESSION['user_email'])) {
?>

  <?php include '../control/anotherActionControl.php'; ?>

  <head>
    <style>
      /* Popup container - can be anything you want */
      .popup {
        position: relative;
        display: inline-block;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      /* The actual popup */
      .popup .popuptext {
        visibility: hidden;
        width: 250px;
        background-color: #555;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 8px 0;
        position: absolute;
        z-index: 1;
        bottom: 136%;
        left: 50%;
        margin-left: -80px;
      }

      /* Popup arrow */
      .popup .popuptext::after {
        content: "";
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: #555 transparent transparent transparent;
      }

      /* Toggle this class - hide and show the popup */
      .popup .show {
        visibility: visible;
        -webkit-animation: fadeIn 1s;
        animation: fadeIn 1s;
      }

      /* Add animation (fade in the popup) */
      @-webkit-keyframes fadeIn {
        from {
          opacity: 0;
        }

        to {
          opacity: 1;
        }
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
        }

        to {
          opacity: 1;
        }
      }
    </style>
  </head>

  <body style="text-align:center">



    <script>
      // When the user clicks on div, open the popup
      function myFunction() {
        var popup = document.getElementById("myPopup");
        popup.classList.toggle("show");
      }
    </script>



    <!-- ------------- -->
    <div align="center" style="padding: 50px">
      <!-- Website Overview -->

      <div class="panel panel-default" align="center" style="padding: 20px">
        <h1 class="panel-title"> Previous history </h1>
        <ul class="nav nav-tabs">
          <li><a data-toggle="tab" href="#menu1">Employee</a></li>
          <li><a data-toggle="tab" href="#menu3">Meal service</a></li>
        </ul>

        <div class="tab-content">

          <div id="menu1" class="tab-pane fade">
            <h3>Employee</h3>
            <div class="panel-body" align="center">

              <br>

              <table class="table table-striped table-hover">
                <tr>
                  <th>No</th>
                  <th>working_type</th>
                  <th>working_duration</th>
                  <th>joining_date</th>
                  <th>start_time</th>
                  <th>end_time</th>
                </tr>
                <?php
                $id = $_SESSION['user_id'];
                $obj = new user();
                $result = $obj->get_employee_previous_post($id);
                $counter = 1;

                while ($row = mysqli_fetch_array($result)) { ?>
                  <tr>
                    <td><?php echo $counter++; ?></td>
                    <td><?php echo $row['working_type']; ?></td>
                    <td><?php echo " " . $row['working_month_or_day_number'] . " , " . $row['working_duration']; ?></td>
                    <td><?php echo $row['joining_date']; ?></td>
                    <td><?php echo $row['work_start_time'] . " Taka "; ?></td>
                    <td><?php echo $row['work_end_time']; ?></td>

                    <td>
                      <a class="btn btn-default" href="previousPostDetails.php?id=<?php echo $row['id_post']; ?>">View </a>

                    </td>
                  </tr>
                <?php } ?>
              </table>
            </div>
          </div>


          <div id="menu3" class="tab-pane fade">
            <br>
            <h3>Meal service </h3>
            <div class="panel-body" align="center">

              <br>

              <table class="table table-striped table-hover">
                <tr>
                  <th>No</th>
                  <th>Meal Type</th>
                  <th>Person</th>
                  <th>Breakfast Time Slot</th>
                  <th>Launch Time Slot</th>
                  <th>meal_other_requirements</th>
                </tr>
                <?php
                $id = $_SESSION['user_id'];
                $obj = new User();
                $result = $obj->get_previous_booking_meal_list($id);
                $counter = 1;


                while ($row = mysqli_fetch_array($result)) { ?>
                  <tr>
                    <td><?php echo $counter++; ?></td>
                    <td><?php echo $row['meal_type']; ?></td>
                    <td><?php echo $row['person']; ?></td>
                    <td><?php echo $row['breakfast_time_slot']; ?></td>
                    <td><?php echo $row['launch_time_slot']; ?></td>
                    <td><?php echo $row['meal_other_requirements']; ?></td>


                  </tr>
                <?php } ?>
              </table>
            </div>

          </div>
        </div>


      </div>

    </div>
    <!-- banner -->


    <div class="container">
      <div class="spacer">
        <div class="row register">


        </div>
      </div>
    </div>
  </body>

  <?php include 'footer2.php'; ?>

<?php } else {
  header("location: ../view/login_user.php");
} ?>