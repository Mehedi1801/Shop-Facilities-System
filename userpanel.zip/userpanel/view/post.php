<?php include'header.php';

//session_start();
if (isset($_SESSION['user_email'])) {
   ?>

   <?php include'../control/employeePostAction.php';?>
   <head>
    <body style="background-image: url(../assets/image/); background-repeat: no-repeat; background-size: cover;">

        <style>
        /* Popup container - can be anything you want */
        .popup {
            position: relative;
            display: inline-block;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* The actual popup */
        .popup .popuptext {
            visibility: hidden;
            width: 250px;
            background-color: #555;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 8px 0;
            position: absolute;
            z-index: 1;
            bottom: 136%;
            left: 50%;
            margin-left: -80px;
        }

        /* Popup arrow */
        .popup .popuptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #555 transparent transparent transparent;
        }

        /* Toggle this class - hide and show the popup */
        .popup .show {
            visibility: visible;
            -webkit-animation: fadeIn 1s;
            animation: fadeIn 1s;
        }

        /* Add animation (fade in the popup) */
        @-webkit-keyframes fadeIn {
            from {opacity: 0;} 
            to {opacity: 1;}
        }

        @keyframes fadeIn {
            from {opacity: 0;}
            to {opacity:1 ;}
        }
        
    </style>
</head>
<body style="text-align:center">



    <script>
// When the user clicks on div, open the popup
function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>




<div class="inside-banner">
  <div class="container"> 
    <h2 align="center"> <p>Post for Employee</p></h2>
</div>
</div>
<!-- banner -->


<div class="container">
    <div class="spacer">
        <div class="row register">
          <div class="col-lg-6 col-lg-offset-3 col-sm-6 col-sm-offset-3 col-xs-12 ">



            <form method="POST" action="post.php">


              <h5>Position</h5>  
                <select name="position" style="width: 556px; height: 46px; border-radius: 6px">
                   <option value="manager">Manager</option>
                   <option value="cashier">Cashier</option>
                   <option value="store_keeper">Store keeper</option>
                   <option value="gate_man">GateMan</option>
               </select>
               <br/>


                


               <h5>Education</h5>
                <select id ="education" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" name="education">
                   <option value="ssc">SSC</option>
                   <option value="hsc">HSC</option>
                   <option value="graduated">Graduated</option>
                   <option value="optional">Education is optional</option>

               </select>


               <h5>Experience</h5>
                <select id ="experience" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" name="experience">
                   <option value="fresher">Fresher</option>
                   <option value="oneyear">1 year</option>
                   <option value="twoyear">2 year</option>
                   <option value="fiveyear">5 year</option>

               </select>


                <h5>Age</h5>
                <select id ="age" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" name="age">
                   <option value="18-23">18-23</option>
                   <option value="24-30">24-30</option>
                   <option value="30++">30++</option>
                   <option value="0">Any</option>

               </select>


               <h5>Select Working Type</h5>  
                <select name="working_type" style="width: 556px; height: 46px; border-radius: 6px">
                   <option value="Full Time">Full Time</option>
                   <option value="Part Time">Part Time</option>
               </select>
               <br/>



               <h5>Working Duration</h5>  
               <select name="working_duration" id="working_duration" onchange="changeMonth()" style="width: 275px; height: 46px; border-radius: 6px">
                   <option value="Day">Day</option>
                   <option value="Month">Month</option>
               </select>


               <select id="month_or_day_number" name="month_or_day_number" style="width: 275px; height: 46px; border-radius: 6px"> 
                  <?php   $count = 1;
                  while( $count <= 30 ) {  ?> 
                    <option value="<?php echo $count ?>"> <?php echo $count ?></option>	
                    <?php  $count++ ; }  ?> 
                </select>


                <h5>Joining Date</h5>
                <input type="date" id="joining_date" min="<?php echo date("Y-d-m"); ?>" class="form-control" placeholder="joining Date" name="joining_date" required>


                <h5>Work starting time</h5>
                <input type="time" id="start_time"class="form-control"   placeholder="time" name="start_time" required>


                <h5>Work ending time</h5>
                <input type="time" id="end_time" class="form-control" placeholder="time" name="end_time" required>

                

              <h5>Salary</h5>  
                <select name="salary" style="width: 556px; height: 46px; border-radius: 6px">
                   <option value="negotiable">Negotiable</option>
                   <option value="8000-10000">8000-10000 /=</option>
                   <option value="10000-20000">10000-20000 /=</option>
                   <option value="20000-30000">20000-30000 /=</option>
                   <option value="30000-50000">30000-50000 /=</option>
               </select>
               <br/>


<h5>Any other Requirements?</h5>
<textarea rows="4" cols="50" class="form-control" placeholder="Details" name="working_details"></textarea>            



<button type="submit" class="btn btn-success" name="post_servant">Submit</button>
<div class="popup" onclick="myFunction()">  Do you forget to fill up some field ?

  <span class="popuptext" id="myPopup"><?php include('errors.php');?></span>
</div>

</form>
</div>

</div>
</div>
</div>
</body>


<script>

    function changeMonth() {

      var x = document.getElementById("working_duration");
      var y = document.getElementById("month_or_day_number");

      if(x.value === "Day"){
        for (var i = 13 ; i < 31 ; i++) {
           var option = document.createElement("option");
           option.text = i;
           y.add(option); 
       }
   } else {

      for (var i = 1 ; i < 19 ; i++) {
        y.remove(12); 
    }
}
}



</script>


<?php include'footer2.php';?>

<?php }else {
  header("location: ../view/login_user.php");
} ?>