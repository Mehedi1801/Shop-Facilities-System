<?php
include 'header.php';
if (isset($_SESSION['user_email'])) {


    include '../control/connection.php';
    include '../control/employeePostUpdateAction.php';
    // include '../control/anotherActionControl.php'; 

?>

    <head>

    <body style="background-image: url(../assets/registration_user/-Playing-with-fruits.jpg); background-repeat: no-repeat; background-size: cover;">

        <style>
            /* Popup container - can be anything you want */
            .popup {
                position: relative;
                display: inline-block;
                cursor: pointer;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            /* The actual popup */
            .popup .popuptext {
                visibility: hidden;
                width: 250px;
                background-color: #555;
                color: #fff;
                text-align: center;
                border-radius: 6px;
                padding: 8px 0;
                position: absolute;
                z-index: 1;
                bottom: 136%;
                left: 50%;
                margin-left: -80px;
            }

            /* Popup arrow */
            .popup .popuptext::after {
                content: "";
                position: absolute;
                top: 100%;
                left: 50%;
                margin-left: -5px;
                border-width: 5px;
                border-style: solid;
                border-color: #555 transparent transparent transparent;
            }

            /* Toggle this class - hide and show the popup */
            .popup .show {
                visibility: visible;
                -webkit-animation: fadeIn 1s;
                animation: fadeIn 1s;
            }

            /* Add animation (fade in the popup) */
            @-webkit-keyframes fadeIn {
                from {
                    opacity: 0;
                }

                to {
                    opacity: 1;
                }
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                }

                to {
                    opacity: 1;
                }
            }
        </style>
        </head>

        <body style="text-align:center">



            <script>
                // When the user clicks on div, open the popup
                function myFunction() {
                    var popup = document.getElementById("myPopup");
                    popup.classList.toggle("show");
                }
            </script>




            <div class="inside-banner">
                <div class="container">
                    <h2 align="center">Employee Info Update</h2>
                </div>
            </div>
            <!-- banner -->


            <div class="container">
                <div class="spacer">
                    <div class="row register">
                        <div class="col-lg-6 col-lg-offset-3 col-sm-6 col-sm-offset-3 col-xs-12 ">

                            <?php include('errors.php');

                            if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                                $id = $_GET['id'];
                            } else {
                                $id = $id_post;
                            }

                            $sql = "SELECT  *  FROM post where id_post = '$id'";

                            $result = mysqli_query($conn, $sql);
                            $counter = 1;

                            while ($row = mysqli_fetch_array($result)) { ?>

                                <!-- <form method="POST" action="../control/employeePostUpdateAction.php"> -->
                         <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
    
                                <h5>Position</h5>
                                    <select name="position" value="<?php echo $row['position'] ?>" style="width: 556px; height: 46px; border-radius: 6px">
                                        <option <?php if($row['position'] == "manager") echo "selected" ; ?> value="manager">Manager</option>
                                        <option <?php if($row['position'] == "cashier") echo "selected" ; ?> value="cashier">Cashier</option>
                                        <option <?php if($row['position'] == "store_keeper") echo "selected" ; ?> value="store_keeper">Store keeper</option>
                                        <option <?php if($row['position'] == "gate_man") echo "selected" ; ?> value="gate_man">GateMan</option>
                                    </select>
                                    <br />


                                    <h5>Education</h5>
                                    <select id="education" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" value="<?php echo $row['education'] ?>" name="education">
                                        <option  <?php if($row['education'] == "ssc") echo "selected" ; ?> value="ssc">SSC</option>
                                        <option  <?php if($row['education'] == "hsc") echo "selected" ; ?> value="hsc">HSC</option>
                                        <option  <?php if($row['education'] == "graduated") echo "selected" ; ?> value="graduated">Graduated</option>
                                        <option  <?php if($row['education'] == "optional") echo "selected" ; ?> value="optional">Education is optional</option>

                                    </select>


                                    <h5>Experience</h5>
                                    <select id="experience" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" value="<?php echo $row['experience'] ?>" name="experience">
                                        <option  <?php if($row['experience'] == "fresher") echo "selected" ; ?> value="fresher">Fresher</option>
                                        <option  <?php if($row['experience'] == "oneyear") echo "selected" ; ?> value="oneyear">1 year</option>
                                        <option  <?php if($row['experience'] == "twoyear") echo "selected" ; ?> value="twoyear">2 year</option>
                                        <option  <?php if($row['experience'] == "fiveyear") echo "selected" ; ?> value="fiveyear">5 year</option>

                                    </select>


                                    <h5>Age</h5>
                                    <select id="age" class="form-control" style="width: 556px; height: 46px; border-radius: 6px" value="<?php echo $row['age'] ?>" name="age">
                                        <option  <?php if($row['age'] == "18-23") echo "selected" ; ?> value="18-23">18-23</option>
                                        <option  <?php if($row['age'] == "24-30") echo "selected" ; ?> value="24-30">24-30</option>
                                        <option  <?php if($row['age'] == "30++") echo "selected" ; ?> value="30++">30++</option>
                                        <option  <?php if($row['age'] == "0") echo "selected" ; ?> value="0">Any</option>

                                    </select>


                                    <h5>Select Working Type</h5>
                                    <select name="working_type" style="width: 556px; height: 46px; border-radius: 6px" value="<?php echo $row['working_type'] ?>">
                                        <option  <?php if($row['working_type'] == "Full Time") echo "selected" ; ?> value="Full Time">Full Time</option>
                                        <option  <?php if($row['working_type'] == "Part Time") echo "selected" ; ?> value="Part Time">Part Time</option>
                                    </select>
                                    <br />



                                    <h5>Working Duration</h5>
                                    <select name="working_duration" id="working_duration" onchange="changeMonth()" value="<?php echo $row['working_duration'] ?>" style="width: 275px; height: 46px; border-radius: 6px">
                                        <option  <?php if($row['working_duration'] == "Day") echo "selected" ; ?> value="Day">Day</option>
                                        <option  <?php if($row['working_duration'] == "Month") echo "selected" ; ?> value="Month">Month</option>
                                    </select>


                                    <select id="month_or_day_number" name="month_or_day_number" style="width: 275px; height: 46px; border-radius: 6px">
                                        <?php $count = 1;
                                        while ($count <= 30) {  ?>
                                            <option  <?php if($row['working_month_or_day_number'] == $count) echo "selected" ; ?> value="<?php echo $count ?>"> <?php echo $count ?></option>
                                        <?php $count++;
                                        }  ?>
                                    </select>


                                    <h5>Joining Date</h5>
                                    <input type="date" id="joining_date" min="<?php echo date("Y-d-m"); ?>" value="<?php echo $row['joining_date'] ?>" class="form-control" placeholder="joining Date" name="joining_date" required>


                                    <h5>Work starting time</h5>
                                    <input type="time" id="start_time" value="<?php echo $row['work_start_time'] ?>" class="form-control" placeholder="time" name="start_time" required>


                                    <h5>Work ending time</h5>
                                    <input type="time" id="end_time" value="<?php echo $row['work_end_time'] ?>" class="form-control" placeholder="time" name="end_time" required>



                                    <h5>Salary</h5>
                                    <select name="salary" value="<?php echo $row['salary'] ?>" style="width: 556px; height: 46px; border-radius: 6px">
                                        <option  <?php if($row['salary'] == "negotiable") echo "selected" ; ?> value="negotiable">Negotiable</option>
                                        <option  <?php if($row['salary'] == "8000-10000") echo "selected" ; ?> value="8000-10000">8000-10000 /=</option>
                                        <option  <?php if($row['salary'] == "10000-20000") echo "selected" ; ?> value="10000-20000">10000-20000 /=</option>
                                        <option  <?php if($row['salary'] == "20000-30000") echo "selected" ; ?> value="20000-30000">20000-30000 /=</option>
                                        <option  <?php if($row['salary'] == "30000-50000") echo "selected" ; ?> value="30000-50000">30000-50000 /=</option>
                                    </select>
                                    <br />


                                    <h5>Any other Requirements?</h5>
                                    <textarea rows="4" cols="50" class="form-control" placeholder="Details" name="working_details"><?php echo $row['working_details'] ?></textarea>



                                    <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
                                    <!-- <textarea rows="6" class="form-control" placeholder="Address" name="address"></textarea> -->

                                    <button type="submit" class="btn btn-success" name="post_update">Update Info</button>
                                <?php } ?>
                        </div>


                        </form>

                    </div>

                </div>
            </div>
            </div>
        </body>

        <?php include 'footer2.php'; ?>

    <?php } else {
    header("location: ../view/login_user.php");
} ?>