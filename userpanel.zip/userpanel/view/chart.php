<?php
include'header.php';
if (isset($_SESSION['user_email'])) {
 ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
  margin-left: 350px;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<center><h2>Daily Meal Chart</h2></center>

  <button style="margin-left: 900px; margin-top: -80px; background: green; color:yellow; height: 50px; width: 70px; " type="submit" class="btn btn-success" name="post_party_center"><a href="meal_booking.php">Back</a> </button>
    


<table style="margin-top: 50px">
  <tr>
    <th>Day</th>
    <th>Breakfast</th>
    <th>Lunch</th>
  </tr>
  <tr>
    <td>Satarday</td>
    <td>Banana, Bread, Tea</td>
    <td>Rice, Vagitable, Fish, Dal</td>
  </tr>
  <tr>
    <td>Sunday</td>
    <td>Hotchpotch</td>
    <td>Pulao, Flesh</td>
  </tr>
  <tr>
    <td>Monday</td>
    <td>Banana, Bread, Tea</td>
    <td>Poulet, Rice, Dal</td>
  </tr>
  <tr>
    <td>Wednesday</td>
    <td>Apple, Biscuits, Tea</td>
    <td>Rice, Vagitable, Fish, Dal</td>
  </tr>
  <tr>
    <td>Thursday</td>
    <td>Banana, Bread, Tea</td>
    <td>Poulet, Rice, Dal</td>
  </tr>
  <tr>
    <td>Friday</td>
    <td>Hotchpotch</td>
    <td>Pulao, Flesh</td>
  </tr>
</table>

</body>
</html>
<?php } else {
  header("location: ../view/login_user.php");
} ?>
