<?php

include('connection.php');



class User
{

	public function create_meal_booking_request($meal_type, $person, $breakfast_time_slot, $launch_time_slot, $meal_other_requirements, $id)
	{

		$GLOBALS['sql'] = "INSERT INTO `meal_booking` (meal_type, person, breakfast_time_slot, launch_time_slot, meal_other_requirements, user_id) VALUES ('$meal_type','$person', '$breakfast_time_slot' ,'$launch_time_slot' , '$meal_other_requirements', '$id');";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}


	public function login_user($email, $password)
	{
		$GLOBALS['sql'] = "SELECT * FROM user WHERE email ='$email' and password ='$password'";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_user_recent_post($u_id)
	{    // 1 neeeeeeddd
		//$GLOBALS['sql'] ="SELECT  *  FROM post where user_id_user = '$u_id'" ;
		$GLOBALS['sql'] = "SELECT  *  FROM post where user_id_user = '$u_id' and id_post not In(select post_id_post from assign where status = 1)";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_employee_previous_post($u_id) // need 
	{    // 1
		$GLOBALS['sql'] = "SELECT  *  FROM post where user_id_user = '$u_id' and id_post In(select post_id_post from assign where status = 1)";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_user_info($email)
	{    // 1
		$GLOBALS['sql'] = "SELECT  *  FROM user where email = '$email' ";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}


	// neeeeeeddddddddd
	public function post_for_employee(
		$position,
		$education,
		$experience,
		$age,
		$working_type,
		$working_duration,
		$month_or_day_number,
		$joining_date,
		$start_time,
		$end_time,
		$salary,
		$working_details,
		$u_id
	) {    // 1

		$GLOBALS['sql'] = "INSERT INTO post (position, education, experience, age, working_type, working_duration, working_month_or_day_number, joining_date, work_start_time, work_end_time, salary, working_details, user_id_user, post_date) VALUES('$position','$education','$experience','$age','$working_type','$working_duration','$month_or_day_number','$joining_date','$start_time','$end_time','$salary','$working_details','$u_id', CURDATE());";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function post_for_employee_update( // need
		$position,
		$education,
		$experience,
		$age,
		$working_type,
		$working_duration,
		$month_or_day_number,
		$joining_date,
		$start_time,
		$end_time,
		$salary,
		$working_details,
		$id_post
	) {    // 1

		$GLOBALS['sql'] = "UPDATE post SET position='$position', education='$education', experience='$experience', age='$age', working_type='$working_type', working_duration='$working_duration', working_month_or_day_number='$month_or_day_number', joining_date='$joining_date', work_start_time='$start_time', work_end_time='$end_time',   salary='$salary', working_details='$working_details' WHERE id_post='$id_post'";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);

		// return $GLOBALS['sql'] ;
	}

	public function get_recent_booking_meal_list($id)
	{
		$GLOBALS['sql'] = "SELECT  *  FROM meal_booking where user_id = '$id' and status = 'pending'";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_previous_booking_meal_list($id)
	{
		$GLOBALS['sql'] = "SELECT  *  FROM meal_booking where user_id = '$id' and status != 'pending'";
		// return $GLOBALS['sql'];

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_servent_list_for_assign($post_id)
	{

		$result = mysqli_query($GLOBALS["conn"], "SELECT maid_servant_id_maid_servent from  assign where post_id_post = $post_id and status = 1");

		if (mysqli_num_rows($result) == 1) {

			$GLOBALS['sql'] = "SELECT * FROM `candidate` where id_candidate In (SELECT maid_servant_id_maid_servent from  assign where post_id_post = '0')";
		} else {

			$GLOBALS['sql'] = "SELECT * FROM `candidate` where id_candidate In (SELECT maid_servant_id_maid_servent from  assign where post_id_post = '$post_id')";
		}
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}


	public function get_isAssign($post_id)
	{
		$GLOBALS['sql'] = "SELECT * from  assign where post_id_post = '$post_id' and status = 1 ";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function accept_servent($post_id, $servent_id)
	{

		$GLOBALS['sql'] = "Update assign set status = 1 where maid_servant_id_maid_servent = '$servent_id' and post_id_post = '$post_id'";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}


	public function get_notification($user_id)
	{

		$GLOBALS['sql'] = "SELECT * FROM `notification` ORDER by accept_time DESC";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function create_laundry_post($iron_quantity, $normal_wash_quantity, $dry_wash_quantity, $delivery_day, $mobile, $user_id_user)
	{

		$GLOBALS['sql'] = "INSERT into laundry (iron_quantity, normal_wash_quantity, dry_wash_quantity, delivery_day, mobile, user_id_user) VALUES ('$iron_quantity', '$normal_wash_quantity', '$dry_wash_quantity', '$delivery_day', '$mobile', '$user_id_user')";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}


	public function get_recent_laundry_list($id)
	{
		$GLOBALS['sql'] = "SELECT  *  FROM laundry where user_id_user = '$id' and status = 'pending'";
		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}

	public function get_previous_laundry_list($id)
	{
		$GLOBALS['sql'] = "SELECT  *  FROM laundry  where user_id_user = '$id' and status != 'pending'";

		return mysqli_query($GLOBALS["conn"], $GLOBALS["sql"]);
	}
}
